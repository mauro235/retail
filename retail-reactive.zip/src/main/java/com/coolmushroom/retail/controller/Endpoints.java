package com.coolmushroom.retail.controller;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Endpoints {
    public static final String GET_PRICE = "/prices";
}
