package com.coolmushroom.retail.core.exception;

public class PriceNotFound extends RuntimeException {
    public PriceNotFound(String message) {
        super(message);
    }
}
