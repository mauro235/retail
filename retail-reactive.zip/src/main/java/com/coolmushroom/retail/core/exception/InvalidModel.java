package com.coolmushroom.retail.core.exception;

public class InvalidModel extends RuntimeException {
    public InvalidModel(String message) {
        super(message);
    }
}
