package com.coolmushroom.retail;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {
    public static final String LOCAL_DATE_TIME_FORMAT_PATTERN = "yyyy-MM-dd HH:mm:ss";
}
